﻿using System;
using System.Windows.Forms;

namespace _10_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bout_Click(object sender, EventArgs e)
        {
            string Fio, Ng; double Nz;

            Student student = new Student();
            if (tbZhiv.Text != "" || tbKG.Text != "" || tbPrezhKG.Text != "")
            {
                Fio = tbZhiv.Text;
                Ng = tbKG.Text;
                try
                {
                    Nz = double.Parse(tbPrezhKG.Text);
                }
                // Обрабатываемый исключение при необходимости вводе числа в текстовом поле
                catch (FormatException)
                {
                    MessageBox.Show("Отсутствует или ошибочный номер группы!!!", "Ошибка");
                    return;
                }
                student.Данные(Fio, Ng, Nz);
            }
            student.Инфорация();
        }

    }
    class Student
    {
        public string fio = "???";
        public string ng = "???"; 
        public double nz; 

        public void Данные(string FIO, string NG, double NZ)
        {
            if (FIO != "") this.fio = FIO;
            if (NG != "") this.ng = NG;
            if (NZ > 0) this.nz = NZ;
            else MessageBox.Show("Номер зачетки должен быть задан положительным числом!!!", "Ошибка");
        }
        public void Инфорация()
        {
            string caption = "Информация о студенте";
            string message = "";

            message = "Студент " + fio + " группы " + ng + " и номером зачетки " + nz;

            
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            MessageBox.Show(message, caption, buttons);
        }
    }
}

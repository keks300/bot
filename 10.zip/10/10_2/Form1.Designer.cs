﻿namespace _10_2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.bout = new System.Windows.Forms.Button();
            this.tbPrezhKG = new System.Windows.Forms.TextBox();
            this.labPrezhVes = new System.Windows.Forms.Label();
            this.tbKG = new System.Windows.Forms.TextBox();
            this.labVes = new System.Windows.Forms.Label();
            this.tbZhiv = new System.Windows.Forms.TextBox();
            this.labNazZhiv = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bout
            // 
            this.bout.BackColor = System.Drawing.Color.LightCoral;
            this.bout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bout.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bout.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bout.Location = new System.Drawing.Point(130, 156);
            this.bout.Name = "bout";
            this.bout.Size = new System.Drawing.Size(267, 55);
            this.bout.TabIndex = 13;
            this.bout.Text = "Вывод информации о студенте";
            this.bout.UseVisualStyleBackColor = false;
            this.bout.Click += new System.EventHandler(this.bout_Click);
            // 
            // tbPrezhKG
            // 
            this.tbPrezhKG.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPrezhKG.Location = new System.Drawing.Point(395, 94);
            this.tbPrezhKG.Multiline = true;
            this.tbPrezhKG.Name = "tbPrezhKG";
            this.tbPrezhKG.Size = new System.Drawing.Size(78, 26);
            this.tbPrezhKG.TabIndex = 12;
            // 
            // labPrezhVes
            // 
            this.labPrezhVes.AutoSize = true;
            this.labPrezhVes.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labPrezhVes.Location = new System.Drawing.Point(269, 94);
            this.labPrezhVes.Name = "labPrezhVes";
            this.labPrezhVes.Size = new System.Drawing.Size(118, 22);
            this.labPrezhVes.TabIndex = 11;
            this.labPrezhVes.Text = "Номер зачатки";
            // 
            // tbKG
            // 
            this.tbKG.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbKG.Location = new System.Drawing.Point(148, 94);
            this.tbKG.Multiline = true;
            this.tbKG.Name = "tbKG";
            this.tbKG.Size = new System.Drawing.Size(78, 26);
            this.tbKG.TabIndex = 10;
            // 
            // labVes
            // 
            this.labVes.AutoSize = true;
            this.labVes.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labVes.Location = new System.Drawing.Point(23, 94);
            this.labVes.Name = "labVes";
            this.labVes.Size = new System.Drawing.Size(114, 22);
            this.labVes.TabIndex = 9;
            this.labVes.Text = "Номер группы";
            // 
            // tbZhiv
            // 
            this.tbZhiv.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbZhiv.Location = new System.Drawing.Point(27, 47);
            this.tbZhiv.Multiline = true;
            this.tbZhiv.Name = "tbZhiv";
            this.tbZhiv.Size = new System.Drawing.Size(483, 26);
            this.tbZhiv.TabIndex = 8;
            // 
            // labNazZhiv
            // 
            this.labNazZhiv.AutoSize = true;
            this.labNazZhiv.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labNazZhiv.Location = new System.Drawing.Point(23, 22);
            this.labNazZhiv.Name = "labNazZhiv";
            this.labNazZhiv.Size = new System.Drawing.Size(115, 22);
            this.labNazZhiv.TabIndex = 7;
            this.labNazZhiv.Text = "ФИО студента";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 241);
            this.Controls.Add(this.bout);
            this.Controls.Add(this.tbPrezhKG);
            this.Controls.Add(this.labPrezhVes);
            this.Controls.Add(this.tbKG);
            this.Controls.Add(this.labVes);
            this.Controls.Add(this.tbZhiv);
            this.Controls.Add(this.labNazZhiv);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bout;
        private System.Windows.Forms.TextBox tbPrezhKG;
        private System.Windows.Forms.Label labPrezhVes;
        private System.Windows.Forms.TextBox tbKG;
        private System.Windows.Forms.Label labVes;
        private System.Windows.Forms.TextBox tbZhiv;
        private System.Windows.Forms.Label labNazZhiv;
    }
}


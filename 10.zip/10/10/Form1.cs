﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Метод, осуществляющий к методам класса Животное
        // при щелчке на кнопке "Вывод информации о животном"
            private void bout_Click(object sender, EventArgs e)
            {
                string Name; double Weight, Weight0;

                Животное животное = new Животное();
                if (tbZhiv.Text != "" || tbKG.Text != "" || tbPrezhKG.Text !="")
                {
                    Name= tbZhiv.Text;
                    try
                    {
                    Weight= double.Parse(tbKG.Text);
                    Weight0 = double.Parse(tbPrezhKG.Text);
                    }
                    // Обрабатываемый исключение при необходимости вводе числа в текстовом поле
                    catch (FormatException)
                    {
                        MessageBox.Show("Отсутствует или ошибочный вес (прежний вес) животного!!!", "Ошибка");
                        return;
                    }
                    животное.Данные(Name, Weight, Weight0);
                }
                животное.Инфорация();
            }

    }        
    class Животное
        {
            public string n = "???"; // Название животного
            public double w; // Вес животного в кг
            public double w0; // Прежний вес животного в кг

            public void Данные(string n, double w, double w0) 
            {
                if (n != "") this.n = n;
                if (w > 0) this.w = w;
                else MessageBox.Show("Вес должен быть задан положительным числом!!!", "Ошибка");
                if (w0 > 0) this.w0 = w0;
                else MessageBox.Show("Прежний вес должен быть задан положительным числом!!!", "Ошибка");
            }
            public void Инфорация()
            {
                string caption = "Информация о животном";
                string message = "";
                if (Привес(w, w0) > 0)
                {
                message = "Животое " + n + " с весом " + w + " кг и прежнем весом " + w0
                    + " поправилась на " + Привес(w, w0) + " кг";
                }
                else if (Привес(w,w0) < 0)
                {
                message = "Животое " + n + " с весом " + w + " кг и прежнем весом " + w0
                    + " похудело на " + Math.Abs(Привес(w, w0)) + " кг";
                }
                else
                {
                message = "Животое " + n + " с весом " + w + " кг и прежнем весом " + w0
                    + " не изменило свой вес";
                }
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, buttons);
            }
        public double Привес(double w, double w0)
        {
            return w-w0;
        }
            
        }
}

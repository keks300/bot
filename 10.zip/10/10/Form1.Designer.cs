﻿namespace _10
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.labNazZhiv = new System.Windows.Forms.Label();
            this.tbZhiv = new System.Windows.Forms.TextBox();
            this.labVes = new System.Windows.Forms.Label();
            this.tbKG = new System.Windows.Forms.TextBox();
            this.tbPrezhKG = new System.Windows.Forms.TextBox();
            this.labPrezhVes = new System.Windows.Forms.Label();
            this.bout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labNazZhiv
            // 
            this.labNazZhiv.AutoSize = true;
            this.labNazZhiv.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labNazZhiv.Location = new System.Drawing.Point(12, 9);
            this.labNazZhiv.Name = "labNazZhiv";
            this.labNazZhiv.Size = new System.Drawing.Size(161, 22);
            this.labNazZhiv.TabIndex = 0;
            this.labNazZhiv.Text = "Название животного:";
            // 
            // tbZhiv
            // 
            this.tbZhiv.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbZhiv.Location = new System.Drawing.Point(16, 34);
            this.tbZhiv.Multiline = true;
            this.tbZhiv.Name = "tbZhiv";
            this.tbZhiv.Size = new System.Drawing.Size(555, 26);
            this.tbZhiv.TabIndex = 1;
            // 
            // labVes
            // 
            this.labVes.AutoSize = true;
            this.labVes.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labVes.Location = new System.Drawing.Point(12, 81);
            this.labVes.Name = "labVes";
            this.labVes.Size = new System.Drawing.Size(146, 22);
            this.labVes.TabIndex = 2;
            this.labVes.Text = "Вес животного в кг:";
            // 
            // tbKG
            // 
            this.tbKG.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbKG.Location = new System.Drawing.Point(164, 81);
            this.tbKG.Multiline = true;
            this.tbKG.Name = "tbKG";
            this.tbKG.Size = new System.Drawing.Size(78, 26);
            this.tbKG.TabIndex = 3;
            // 
            // tbPrezhKG
            // 
            this.tbPrezhKG.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPrezhKG.Location = new System.Drawing.Point(493, 81);
            this.tbPrezhKG.Multiline = true;
            this.tbPrezhKG.Name = "tbPrezhKG";
            this.tbPrezhKG.Size = new System.Drawing.Size(78, 26);
            this.tbPrezhKG.TabIndex = 5;
            // 
            // labPrezhVes
            // 
            this.labPrezhVes.AutoSize = true;
            this.labPrezhVes.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labPrezhVes.Location = new System.Drawing.Point(272, 81);
            this.labPrezhVes.Name = "labPrezhVes";
            this.labPrezhVes.Size = new System.Drawing.Size(215, 22);
            this.labPrezhVes.TabIndex = 4;
            this.labPrezhVes.Text = "Прежний вес животного в кг:";
            // 
            // bout
            // 
            this.bout.BackColor = System.Drawing.Color.LightCoral;
            this.bout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bout.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bout.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bout.Location = new System.Drawing.Point(164, 143);
            this.bout.Name = "bout";
            this.bout.Size = new System.Drawing.Size(267, 55);
            this.bout.TabIndex = 6;
            this.bout.Text = "Вывод информации о животном";
            this.bout.UseVisualStyleBackColor = false;
            this.bout.Click += new System.EventHandler(this.bout_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 227);
            this.Controls.Add(this.bout);
            this.Controls.Add(this.tbPrezhKG);
            this.Controls.Add(this.labPrezhVes);
            this.Controls.Add(this.tbKG);
            this.Controls.Add(this.labVes);
            this.Controls.Add(this.tbZhiv);
            this.Controls.Add(this.labNazZhiv);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Form1";
            this.Text = "Класс \"Животное\": название, вес и прежний вес";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labNazZhiv;
        private System.Windows.Forms.TextBox tbZhiv;
        private System.Windows.Forms.Label labVes;
        private System.Windows.Forms.TextBox tbKG;
        private System.Windows.Forms.TextBox tbPrezhKG;
        private System.Windows.Forms.Label labPrezhVes;
        private System.Windows.Forms.Button bout;
    }
}

